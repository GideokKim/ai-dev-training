# AI 개발자 교육 · 발표자 묶음

ZIP 전체를 압축 해제한 뒤 [START_HERE.html](START_HERE.html)을 여세요.

80장/360분. 로컬 자료 준비 완료, 실환경·리허설 UNVERIFIED.
기본 Demo는 정적 PPT/PNG입니다. 원본 터미널 캡처·녹화·현재 제품 실행을 뜻하지 않습니다.
PowerPoint 발표는 실제 발표 PC에서 별도 확인해야 합니다.

강사용 준비 묶음이며 청중 배포 또는 외부 전달 승인 완료를 뜻하지 않습니다.
기획·Trial·연구 문서는 역사적 출처 확인용입니다.

개별 파일은 PACKAGE_MANIFEST.json, ZIP 자체는 원본 ZIP 옆 sha256 파일로 확인합니다.
별도 실행 코드·설정·계정·Demo 저장소를 포함하지 않습니다.
